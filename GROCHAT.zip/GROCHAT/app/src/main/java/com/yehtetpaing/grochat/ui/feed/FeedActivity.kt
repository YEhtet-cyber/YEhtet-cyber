package com.yehtetpaing.grochat.ui.feed

import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.firebase.auth.FirebaseAuth
import com.yehtetpaing.grochat.R
import com.yehtetpaing.grochat.ui.login.LoginActivity
import com.yehtetpaing.grochat.ui.adapter.PostAdapter
import com.yehtetpaing.grochat.ui.viewmodel.FeedViewModel
import com.yehtetpaing.grochat.ui.post.PostActivity

class FeedActivity : AppCompatActivity() {

    private lateinit var auth: FirebaseAuth
    private lateinit var feedRecyclerView: RecyclerView
    private lateinit var postAdapter: PostAdapter
    private lateinit var viewModel: FeedViewModel
    private lateinit var fabPost: FloatingActionButton

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_feed)

        auth = FirebaseAuth.getInstance()
        viewModel = ViewModelProvider(this)[FeedViewModel::class.java]

        feedRecyclerView = findViewById(R.id.feedRecyclerView)
        feedRecyclerView.layoutManager = LinearLayoutManager(this)
        postAdapter = PostAdapter(emptyList()) // Initially empty list
        feedRecyclerView.adapter = postAdapter

        fabPost = findViewById(R.id.fabPost)
        fabPost.setOnClickListener {
            startActivity(Intent(this, PostActivity::class.java))
        }

        viewModel.posts.observe(this) { posts ->
            postAdapter.updatePosts(posts)
        }

        viewModel.fetchFollowingPosts()
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu_main, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_logout -> {
                auth.signOut()
                startActivity(Intent(this, LoginActivity::class.java))
                finish()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }
}
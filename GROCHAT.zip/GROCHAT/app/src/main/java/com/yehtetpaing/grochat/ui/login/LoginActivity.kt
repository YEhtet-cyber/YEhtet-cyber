@file:Suppress("DEPRECATION")

package com.yehtetpaing.grochat.ui.login

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ProgressBar
import android.widget.TextView
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.ApiException
import com.google.firebase.auth.FirebaseAuth
import com.yehtetpaing.grochat.R
import com.yehtetpaing.grochat.ui.feed.FeedActivity
import com.yehtetpaing.grochat.ui.viewmodel.LoginViewModel

class LoginActivity : AppCompatActivity() {

    private lateinit var auth: FirebaseAuth
    private lateinit var googleSignInClient: GoogleSignInClient
    private lateinit var googleSignInLauncher: ActivityResultLauncher<Intent>
    private lateinit var loadingProgressBar: ProgressBar
    private lateinit var errorMessageTextView: TextView
    private lateinit var viewModel: LoginViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        auth = FirebaseAuth.getInstance()
        viewModel = ViewModelProvider(this)[LoginViewModel::class.java]

        loadingProgressBar = findViewById(R.id.loadingProgressBar)
        errorMessageTextView = findViewById(R.id.errorMessageTextView)
        val gmailSignInButton: Button = findViewById(R.id.gmailSignInButton)

        // Configure Google Sign In using GoogleSignInOptions
        val gso = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestIdToken(getString(R.string.default_web_client_id))
            .requestEmail()
            .build()

        // Initialize GoogleSignInClient
        googleSignInClient = GoogleSignIn.getClient(this, gso)

        googleSignInLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == RESULT_OK) {
                val task = GoogleSignIn.getSignedInAccountFromIntent(result.data)
                try {
                    val account = task.getResult(ApiException::class.java)!!
                    firebaseAuthWithGoogle(account.idToken!!)
                } catch (e: ApiException) {
                    // Google Sign In failed, update UI appropriately
                    errorMessageTextView.text = getString(R.string.google_sign_in_failed, e.message)
                    errorMessageTextView.visibility = View.VISIBLE
                    loadingProgressBar.visibility = View.GONE
                }
            } else {
                errorMessageTextView.text = getString(R.string.google_sign_in_cancelled)
                errorMessageTextView.visibility = View.VISIBLE
                loadingProgressBar.visibility = View.GONE
            }
        }

        gmailSignInButton.setOnClickListener {
            signInWithGoogle()
        }

        viewModel.loginResult.observe(this) { loginResult ->
            loadingProgressBar.visibility = View.GONE
            if (loginResult.error != null) {
                errorMessageTextView.text = getString(loginResult.error)
                errorMessageTextView.visibility = View.VISIBLE
            }
            if (loginResult.success != null) {
                updateUiWithUser()
            }
        }

        // အရင် login ဝင်ထားပြီးသားဆိုရင် FeedActivity ကို တန်းသွားမယ်
        if (auth.currentUser != null) {
            updateUiWithUser()
        }
    }

    private fun signInWithGoogle() {
        loadingProgressBar.visibility = View.VISIBLE
        errorMessageTextView.visibility = View.GONE
        val signInIntent = googleSignInClient.signInIntent // GoogleSignInClient ရဲ့ signInIntent ကို သုံးပါ
        googleSignInLauncher.launch(signInIntent)
    }

    private fun firebaseAuthWithGoogle(idToken: String) {
        viewModel.firebaseAuthWithGoogle(idToken)
    }

    private fun updateUiWithUser() {
        val intent = Intent(this, FeedActivity::class.java)
        startActivity(intent)
        finish()
    }
}
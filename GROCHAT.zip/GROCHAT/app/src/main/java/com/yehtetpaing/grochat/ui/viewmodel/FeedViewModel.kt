package com.yehtetpaing.grochat.ui.viewmodel

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.yehtetpaing.grochat.data.model.Post
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

class FeedViewModel : ViewModel() {

    private val _posts = MutableLiveData<List<Post>>()
    val posts: LiveData<List<Post>> = _posts
    private val firestore = FirebaseFirestore.getInstance()
    private val auth = FirebaseAuth.getInstance()

    init {
        fetchFollowingPosts()
    }

    fun fetchFollowingPosts() {
        viewModelScope.launch {
            try {
                val currentUser = auth.currentUser
                currentUser?.let { user ->
                    val followingResult = firestore.collection("users")
                        .document(user.uid)
                        .get()
                        .await()

                    val followingList = followingResult.get("following")
                    val stringFollowingList: List<String> = if (followingList is List<*>) {
                        followingList.filterIsInstance<String>()
                    } else {
                        emptyList()
                    }

                    val postsFromFollowing = mutableListOf<Post>()
                    for (followedUserId in stringFollowingList) {
                        val followedUserPostsResult = firestore.collection("posts")
                            .whereEqualTo("userId", followedUserId)
                            .get()
                            .await()
                        for (document in followedUserPostsResult) {
                            val post = document.toObject(Post::class.java)
                            post.postId = document.id // Document ID ကို Post ထဲထည့်ရန်
                            postsFromFollowing.add(post)
                        }
                    }
                    _posts.value = postsFromFollowing.sortedByDescending { it.timestamp }
                }
            } catch (e: Exception) {
                // Handle error
                Log.e("FeedViewModel", "Error fetching following posts: ${e.message}")
            }
        }
    }
}
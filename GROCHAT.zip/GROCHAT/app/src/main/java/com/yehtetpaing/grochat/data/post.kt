package com.yehtetpaing.grochat.data.model

data class Post(
    var postId: String? = null,
    val userId: String? = null,
    val userName: String? = null,
    val text: String? = null,
    val timestamp: Long? = System.currentTimeMillis(),
    val likes: List<String>? = emptyList(),
    val hearts: List<String>? = emptyList()
    // တခြား Post နဲ့ ဆိုင်တဲ့ အချက်အလက်တွေကို ဒီမှာ ထပ်ထည့်နိုင်ပါတယ်
)
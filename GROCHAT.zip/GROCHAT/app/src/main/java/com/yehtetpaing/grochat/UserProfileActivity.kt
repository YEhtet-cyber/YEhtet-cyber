package com.yehtetpaing.grochat // Replace with your actual package name

import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.RecyclerView

class UserProfileActivity : AppCompatActivity() {

    private lateinit var coverImageView: ImageView
    private lateinit var profileImageView: ImageView
    private lateinit var usernameTextView: TextView
    private lateinit var displayNameTextView: TextView
    private lateinit var bioTextView: TextView
    private lateinit var followingCountTextView: TextView
    private lateinit var followersCountTextView: TextView
    private lateinit var editProfileButton: Button
    private lateinit var userPostsRecyclerView: RecyclerView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_user_profile)

        // Initialize views
        coverImageView = findViewById(R.id.coverImageView)
        profileImageView = findViewById(R.id.profileImageView)
        usernameTextView = findViewById(R.id.usernameTextView)
        displayNameTextView = findViewById(R.id.displayNameTextView)
        bioTextView = findViewById(R.id.bioTextView)
        followingCountTextView = findViewById(R.id.followingCountTextView)
        followersCountTextView = findViewById(R.id.followersCountTextView)
        editProfileButton = findViewById(R.id.editProfileButton)
        userPostsRecyclerView = findViewById(R.id.userPostsRecyclerView)

        // Load user profile data (replace with your actual data fetching logic)
        loadUserProfile()

        // Set up RecyclerView (you'll need a LayoutManager and Adapter)
        // userPostsRecyclerView.layoutManager = LinearLayoutManager(this)
        // userPostsRecyclerView.adapter = UserPostsAdapter(listOf()) // Replace with your adapter and data

        // Set click listener for edit profile button
        editProfileButton.setOnClickListener {
            // Implement edit profile functionality here
        }

        // Enable the back button in the ActionBar
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
    }

    private fun loadUserProfile() {
        // Replace these with actual data from your data source (e.g., Firebase, local database)
        //coverImageView.setImageResource(R.drawable.default_cover) // Replace with your default cover image
        profileImageView.setImageResource(R.drawable.ic_user_placeholder) // Replace with your default profile image
        usernameTextView.text = "sample_username"
        displayNameTextView.text = "Sample Display Name"
        bioTextView.text = "This is a sample user bio."
        followingCountTextView.text = "10 Following"
        followersCountTextView.text = "15 Followers"
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        // You can add menu items here if needed
        return super.onCreateOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        // Handle action bar item clicks here
        when (item.itemId) {
            android.R.id.home -> {
                finish() // Go back to the previous activity
                return true
            }
            // Add other menu item handling here if needed
        }
        return super.onOptionsItemSelected(item)
    }
}
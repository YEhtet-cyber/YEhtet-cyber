package com.yehtetpaing.grochat.data.model

data class User(
    val userId: String? = null,
    val userName: String? = null,
    val email: String? = null,
    val profileImageUrl: String? = null
    // တခြား User နဲ့ ဆိုင်တဲ့ အချက်အလက်တွေကို ဒီမှာ ထပ်ထည့်နိုင်ပါတယ်
)
package com.yehtetpaing.grochat.ui.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.yehtetpaing.grochat.R
import com.yehtetpaing.grochat.data.model.Post
import kotlinx.coroutines.launch
import java.util.Date
import java.util.UUID


data class PostResult(val success: Boolean = false, val error: Int? = null)

class PostViewModel : ViewModel() {

    private val _postResult = MutableLiveData<PostResult>()
    val postResult: LiveData<PostResult> = _postResult
    private val firestore = FirebaseFirestore.getInstance()
    private val auth = FirebaseAuth.getInstance()

    fun postText(text: String) {
        viewModelScope.launch {
            try {
                val currentUser = auth.currentUser
                currentUser?.let { user ->
                    val postId = UUID.randomUUID().toString()
                    val post = Post(
                        postId = postId,
                        userId = user.uid,
                        userName = user.displayName ?: "Anonymous",
                        text = text,
                        timestamp = Date().time,
                        likes = emptyList(),
                        hearts = emptyList()
                    )
                    firestore.collection("posts")
                        .document(postId)
                        .set(post)
                        .addOnSuccessListener {
                            _postResult.value = PostResult(success = true)
                        }
                        .addOnFailureListener {
                            _postResult.value = PostResult(error = R.string.post_failed)
                        }
                }
            } catch (e: Exception) {
                _postResult.value = PostResult(error = R.string.post_failed)
            }
        }
    }
}
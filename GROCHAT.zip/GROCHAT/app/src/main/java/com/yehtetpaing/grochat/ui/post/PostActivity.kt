package com.yehtetpaing.grochat.ui.post

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import com.google.firebase.auth.FirebaseAuth
import com.yehtetpaing.grochat.R
import com.yehtetpaing.grochat.ui.feed.FeedActivity
import com.yehtetpaing.grochat.ui.viewmodel.PostViewModel // ဒီနေရာကို ရွှေ့လိုက်ပါပြီ

class PostActivity : AppCompatActivity() {

    private lateinit var postEditText: EditText
    private lateinit var postButton: Button
    private lateinit var postingProgressBar: ProgressBar
    private lateinit var postErrorMessageTextView: TextView
    private lateinit var viewModel: PostViewModel
    private lateinit var auth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_post)

        auth = FirebaseAuth.getInstance()
        viewModel = ViewModelProvider(this)[PostViewModel::class.java]

        postEditText = findViewById(R.id.postEditText)
        postButton = findViewById(R.id.postButton)
        postingProgressBar = findViewById(R.id.postingProgressBar)
        postErrorMessageTextView = findViewById(R.id.postErrorMessageTextView)

        postButton.setOnClickListener {
            val text = postEditText.text.toString().trim()
            if (text.isNotEmpty()) {
                postingProgressBar.visibility = View.VISIBLE
                postErrorMessageTextView.visibility = View.GONE
                viewModel.postText(text)
            } else {
                Toast.makeText(this, "Please enter some text", Toast.LENGTH_SHORT).show()
            }
        }

        viewModel.postResult.observe(this) { postResult ->
            postingProgressBar.visibility = View.GONE
            if (postResult.error != null) {
                postErrorMessageTextView.text = getString(postResult.error)
                postErrorMessageTextView.visibility = View.VISIBLE
            }
            if (postResult.success) {
                Toast.makeText(this, "Posted successfully", Toast.LENGTH_SHORT).show()
                finish() // Go back to feed after posting
            }
        }
    }
}
package com.yehtetpaing.grochat.ui.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.GoogleAuthProvider
import com.yehtetpaing.grochat.R
import kotlinx.coroutines.launch

data class LoginResult(val success: Boolean? = null, val error: Int? = null)

class LoginViewModel : ViewModel() {

    private val _loginResult = MutableLiveData<LoginResult>()
    val loginResult: LiveData<LoginResult> = _loginResult
    private val auth = FirebaseAuth.getInstance()

    fun firebaseAuthWithGoogle(idToken: String) {
        viewModelScope.launch {
            try {
                val credential = GoogleAuthProvider.getCredential(idToken, null)
                auth.signInWithCredential(credential)
                    .addOnCompleteListener { task ->
                        if (task.isSuccessful) {
                            _loginResult.value = LoginResult(success = true)
                        } else {
                            _loginResult.value = LoginResult(error = R.string.login_failed)
                        }
                    }
            } catch (_: Exception) {
                _loginResult.value = LoginResult(error = R.string.login_failed)
            }
        }
    }
}
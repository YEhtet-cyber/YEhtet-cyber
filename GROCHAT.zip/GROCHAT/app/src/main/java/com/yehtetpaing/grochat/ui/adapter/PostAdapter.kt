package com.yehtetpaing.grochat.ui.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.yehtetpaing.grochat.R
import com.yehtetpaing.grochat.data.model.Post

class PostAdapter(private var posts: List<Post>) : RecyclerView.Adapter<PostAdapter.PostViewHolder>() {

    private val firestore = FirebaseFirestore.getInstance()
    private val auth = FirebaseAuth.getInstance()

    class PostViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val userNameTextView: TextView = itemView.findViewById(R.id.userNameTextView)
        val postTextView: TextView = itemView.findViewById(R.id.postTextView)
        val likeButton: ImageView = itemView.findViewById(R.id.likeButton)
        val likeCountTextView: TextView = itemView.findViewById(R.id.likeCountTextView)
        val heartButton: ImageView = itemView.findViewById(R.id.heartButton)
        val heartCountTextView: TextView = itemView.findViewById(R.id.heartCountTextView)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PostViewHolder {
        val itemView = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_post, parent, false)
        return PostViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: PostViewHolder, position: Int) {
        val currentPost = posts[position]
        holder.userNameTextView.text = currentPost.userName
        holder.postTextView.text = currentPost.text

        holder.likeCountTextView.text = currentPost.likes?.size.toString()
        holder.heartCountTextView.text = currentPost.hearts?.size.toString()

        val currentUserUid = auth.currentUser?.uid

        val isLiked = currentPost.likes?.contains(currentUserUid) == true
        holder.likeButton.setImageResource(if (isLiked) R.drawable.ic_thumb_up else R.drawable.ic_thumb_up) // ပြောင်းလဲထားသော ရုပ်ပုံ

        val isHearted = currentPost.hearts?.contains(currentUserUid) == true
        holder.heartButton.setImageResource(if (isHearted) R.drawable.ic_heart else R.drawable.ic_heart) // ပြောင်းလဲထားသော ရုပ်ပုံ

        holder.likeButton.setOnClickListener {
            currentUserUid?.let { uid ->
                val postRef = firestore.collection("posts").document(currentPost.postId!!)
                val isCurrentlyLiked = currentPost.likes?.contains(uid) == true
                if (isCurrentlyLiked) {
                    postRef.update("likes", FieldValue.arrayRemove(uid))
                } else {
                    postRef.update("likes", FieldValue.arrayUnion(uid))
                }
            }
        }

        holder.heartButton.setOnClickListener {
            currentUserUid?.let { uid ->
                val postRef = firestore.collection("posts").document(currentPost.postId!!)
                val isCurrentlyHearted = currentPost.hearts?.contains(uid) == true
                if (isCurrentlyHearted) {
                    postRef.update("hearts", FieldValue.arrayRemove(uid))
                } else {
                    postRef.update("hearts", FieldValue.arrayUnion(uid))
                }
            }
        }
    }

    override fun getItemCount() = posts.size

    fun updatePosts(newPosts: List<Post>) {
        val diffResult = DiffUtil.calculateDiff(PostDiffCallback(posts, newPosts))
        posts = newPosts
        diffResult.dispatchUpdatesTo(this)
    }
}

class PostDiffCallback(private val oldList: List<Post>, private val newList: List<Post>) : DiffUtil.Callback() {

    override fun getOldListSize() = oldList.size

    override fun getNewListSize() = newList.size

    override fun areItemsTheSame(oldItemPosition: Int, newItemPosition: Int) =
        oldList[oldItemPosition].postId == newList[newItemPosition].postId

    override fun areContentsTheSame(oldItemPosition: Int, newItemPosition: Int) =
        oldList[oldItemPosition] == newList[newItemPosition]
}